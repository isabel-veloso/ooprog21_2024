/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Sabel
 */
public class MyListings extends javax.swing.JFrame {

    private String username; // Logged-in username
    private String role; // User's role
    private JPanel listingsPanel; // Panel to hold user items
    private String selectedItemName = null; // To track the selected item

    /**
     * Creates new form MyListings
     */
    public MyListings(String username, String role) {
        this.username = username;
        this.role = role; // Store the role
        initComponents();
        listingsPanel = new JPanel();
        listingsPanel.setLayout(new GridLayout(0, 4, 10, 10)); // 4 columns, 10px gaps
        jScrollPane1.setViewportView(listingsPanel);
        loadUserListings(); // Load listings on initialization
    }
    
    public void refreshListings() {
        loadUserListings();
        JOptionPane.showMessageDialog(this, "Your listings have been updated!");
    }

    private void loadUserListings() {
        resetButtonState(availableItemButton, false, Color.GRAY);
        resetButtonState(notAvailableButton, false, Color.GRAY);

        listingsPanel.removeAll(); // Clear previous listings

        try (Connection con = MyConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM products WHERE username = ?")) {

            ps.setString(1, username); // Bind the logged-in username
            ResultSet rs = ps.executeQuery();

            boolean hasListings = false;
            while (rs.next()) {
                hasListings = true;
                String name = rs.getString("name");
                String description = rs.getString("description");
                double price = rs.getDouble("price");
                String imagePath = rs.getString("image_path");
                boolean isRented = rs.getBoolean("rented");

                JPanel listingPanel = createListingPanel(name, description, price, imagePath, isRented);
                listingsPanel.add(listingPanel);
            }

            if (!hasListings) {
                JLabel noListingsLabel = new JLabel("You haven't listed any items yet!", SwingConstants.CENTER);
                noListingsLabel.setFont(new Font("Arial", Font.ITALIC, 18));
                noListingsLabel.setForeground(Color.GRAY);
                listingsPanel.add(noListingsLabel);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading listings: " + e.getMessage());
        }

        listingsPanel.revalidate();
        listingsPanel.repaint();
    }

    private JPanel createListingPanel(String name, String description, double price, String imagePath, boolean isRented) {
        JPanel listingPanel = new JPanel(new BorderLayout());
        listingPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        listingPanel.setPreferredSize(new Dimension(150, 150));
        listingPanel.setBackground(new Color(245, 245, 245));

        JLabel imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);

        try {
            ImageIcon icon = new ImageIcon(new ImageIcon(resolveImagePath(imagePath)).getImage()
                    .getScaledInstance(100, 100, Image.SCALE_SMOOTH));
            imageLabel.setIcon(icon);
        } catch (Exception e) {
            System.err.println("Error loading image for item: " + name + ". Using default image.");
            imageLabel.setIcon(new ImageIcon("images/placeholder.png"));
        }
        listingPanel.add(imageLabel, BorderLayout.CENTER);

        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.Y_AXIS));
        detailsPanel.setBackground(new Color(245, 245, 245));

        JLabel nameLabel = new JLabel(name);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel priceLabel = new JLabel("₱" + String.format("%.2f", price));
        priceLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        priceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel rentedStatus = new JLabel(isRented ? "Status: Rented" : "Status: Available");
        rentedStatus.setFont(new Font("Arial", Font.ITALIC, 12));
        rentedStatus.setAlignmentX(Component.CENTER_ALIGNMENT);

        detailsPanel.add(nameLabel);
        detailsPanel.add(priceLabel);
        detailsPanel.add(rentedStatus);

        listingPanel.add(detailsPanel, BorderLayout.SOUTH);

        listingPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                handleItemClick(name, isRented);
            }

            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                listingPanel.setBackground(new Color(220, 220, 220));
                listingPanel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                listingPanel.setBackground(new Color(245, 245, 245));
                listingPanel.setCursor(Cursor.getDefaultCursor());
            }
        });

        return listingPanel;
    }

    private void handleItemClick(String itemName, boolean isRented) {
        selectedItemName = itemName;

        if (isRented) {
            resetButtonState(availableItemButton, true, Color.GREEN);
            resetButtonState(notAvailableButton, false, Color.GRAY);
        } else {
            resetButtonState(notAvailableButton, true, Color.RED);
            resetButtonState(availableItemButton, false, Color.GRAY);
        }
    }

    private String resolveImagePath(String imagePath) {
        File file = new File(imagePath);
        return (file.exists() && file.isFile()) ? imagePath : "images/placeholder.png";
    }

    private void resetButtonState(JButton button, boolean isEnabled, Color color) {
        button.setEnabled(isEnabled);
        button.setBackground(color);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        logoutButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        rentRequestsButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        notAvailableButton = new javax.swing.JButton();
        availableItemButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 600));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 51, 102));
        jPanel1.setPreferredSize(new java.awt.Dimension(1000, 75));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gearshare/GearShareLogo.png"))); // NOI18N

        logoutButton.setBackground(new java.awt.Color(255, 255, 255));
        logoutButton.setForeground(new java.awt.Color(0, 51, 102));
        logoutButton.setText("↪");
        logoutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutButtonActionPerformed(evt);
            }
        });

        backButton.setBackground(new java.awt.Color(255, 255, 255));
        backButton.setForeground(new java.awt.Color(0, 51, 102));
        backButton.setText("🔙");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(backButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 326, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(378, 378, 378)
                .addComponent(logoutButton)
                .addGap(14, 14, 14))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(logoutButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(backButton)
                .addGap(18, 18, 18))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 80));

        jPanel2.setBackground(new java.awt.Color(0, 51, 102));
        jPanel2.setPreferredSize(new java.awt.Dimension(100, 520));
        jPanel2.setRequestFocusEnabled(false);

        rentRequestsButton.setBackground(new java.awt.Color(255, 255, 255));
        rentRequestsButton.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 12)); // NOI18N
        rentRequestsButton.setForeground(new java.awt.Color(0, 51, 102));
        rentRequestsButton.setText("rent requests");
        rentRequestsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rentRequestsButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(rentRequestsButton)
                .addGap(15, 15, 15))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(117, 117, 117)
                .addComponent(rentRequestsButton)
                .addContainerGap(377, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 130, 520));
        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 870, 460));

        notAvailableButton.setText("mark as not available");
        notAvailableButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                notAvailableButtonActionPerformed(evt);
            }
        });
        getContentPane().add(notAvailableButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 550, -1, -1));

        availableItemButton.setText("mark as available");
        availableItemButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                availableItemButtonActionPerformed(evt);
            }
        });
        availableItemButton.setEnabled(false); // Disable the button initially
        availableItemButton.setBackground(Color.GRAY); // Set a neutral color
        getContentPane().add(availableItemButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 550, -1, -1));

        setSize(new java.awt.Dimension(1014, 637));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        if ("admin".equals(role)) {
            new AdminPage().setVisible(true);
        } else {
            new Dashboard(username, role).setVisible(true);
        }
        this.dispose();
    }//GEN-LAST:event_backButtonActionPerformed

    private void availableItemButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_availableItemButtonActionPerformed
        // TODO add your handling code here:
        updateItemAvailability(false, "Item is now available.");
    }//GEN-LAST:event_availableItemButtonActionPerformed

    
    private void rentRequestsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rentRequestsButtonActionPerformed
        // TODO add your handling code here:
        RentRequestsFrame rentRequestsFrame = new RentRequestsFrame(username);
        rentRequestsFrame.setVisible(true);
        this.dispose(); // Close the current frame
    }//GEN-LAST:event_rentRequestsButtonActionPerformed

    private void notAvailableButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_notAvailableButtonActionPerformed
        // TODO add your handling code here:
        updateItemAvailability(true, "Item marked as not available.");
    }//GEN-LAST:event_notAvailableButtonActionPerformed
    private void updateItemAvailability(boolean isRented, String successMessage) {
            if (selectedItemName == null) {
                JOptionPane.showMessageDialog(this, "Please select an item first.");
                return;
            }

            try (Connection con = MyConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(
                         "UPDATE products SET rented = ? WHERE name = ? AND username = ?")) {

                ps.setBoolean(1, isRented);
                ps.setString(2, selectedItemName);
                ps.setString(3, username);

                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(this, successMessage);
                    refreshListings();
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to update item availability.");
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            }
        }
    private void logoutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutButtonActionPerformed
        // TODO add your handling code here:
        new Login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logoutButtonActionPerformed


    // Handle request approval/rejection
    
    private void markItemAsRented(int requestId) {
        try (Connection con = MyConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                 "UPDATE products SET rented = 1 WHERE id = (SELECT product_id FROM rental_requests WHERE id = ?)")) {

            ps.setInt(1, requestId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to mark item as rented: " + e.getMessage());
        }
    }
    
    /**
     * @param args the command line arguments
     */
    
    
    
        public static void main(String args[]) {
            /* Set the Nimbus look and feel */
            //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
            /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
             * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
             */
            try {
                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (ClassNotFoundException ex) {
                java.util.logging.Logger.getLogger(MyListings.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (InstantiationException ex) {
                java.util.logging.Logger.getLogger(MyListings.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                java.util.logging.Logger.getLogger(MyListings.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (javax.swing.UnsupportedLookAndFeelException ex) {
                java.util.logging.Logger.getLogger(MyListings.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            }
            //</editor-fold>
            /* Create and display the form */
            java.awt.EventQueue.invokeLater(() -> {
            new MyListings("test", "user").setVisible(true);
            });
        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton availableItemButton;
    private javax.swing.JButton backButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logoutButton;
    private javax.swing.JButton notAvailableButton;
    private javax.swing.JButton rentRequestsButton;
    // End of variables declaration//GEN-END:variables
}
