
import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Sabel
 */
public class RentedItemsFrame extends javax.swing.JFrame {
    private String username;

    /**
     * Creates new form RentedItemsFrame
     */
    public RentedItemsFrame(String username) {
        this.username = username;
        initComponents();
        loadRentedItems();
        addTableClickListener();
    }
    
    private void loadRentedItems() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); // Clear existing rows

        try (Connection con = MyConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                 "SELECT rr.id AS 'Request ID', p.name AS 'Item Name', rr.renter_username AS 'Renter', " +
                 "rr.status AS 'Status', rr.request_date AS 'Request Date', rr.days AS 'Days Requested', " +
                 "u.emailAddress AS 'Owner Email', u.contactNumber AS 'Owner Contact' " +
                 "FROM rental_requests rr " +
                 "JOIN products p ON rr.product_id = p.id " +
                 "JOIN users u ON p.username = u.username " +
                 "WHERE rr.renter_username = ?")) { // Filters by current user's username

            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("Request ID"),
                    rs.getString("Item Name"),
                    rs.getString("Renter"),
                    rs.getString("Status"),
                    rs.getTimestamp("Request Date"),
                    rs.getInt("Days Requested"),
                    rs.getString("Owner Email"),
                    rs.getString("Owner Contact"),
                    "View Invoice" // Static clickable text for invoices
                });
            }

            // Update messageLabel based on the first row's status
            if (model.getRowCount() > 0) {
                String status = (String) model.getValueAt(0, 3); // Status of the first row
                updateMessageLabel(status);
            } else {
                messageLabel.setText("<html>No requests to display.</html>");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to load rented items: " + e.getMessage());
        }
    }

    /**
     * Updates the message label with the status of the first request.
     * @param status The status of the rental request.
     */
    private void updateMessageLabel(String status) {
        if ("approved".equalsIgnoreCase(status)) {
            messageLabel.setText("<html>Your request has been approved.<br>Please contact the owner.</html>");
        } else if ("rejected".equalsIgnoreCase(status)) {
            messageLabel.setText("<html>Your request has been rejected.</html>");
        } else {
            messageLabel.setText("<html>The request is still pending.</html>");
        }
    }

    /**
     * Adds a click listener to the table to handle cell-specific actions.
     */
    private void addTableClickListener() {
        jTable1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                int row = jTable1.rowAtPoint(evt.getPoint());
                int col = jTable1.columnAtPoint(evt.getPoint()); // Get clicked column

                if (row >= 0) {
                    if (col == 8) { // "Invoice" column index
                        handleInvoiceClick(row);
                    } else {
                        handleRowClick(row); // Handle status and general row clicks
                    }
                }
            }
        });
    }
    
    private void handleRowClick(int row) {
        String status = (String) jTable1.getValueAt(row, 3); // Status column
        String ownerEmail = (String) jTable1.getValueAt(row, 6); // Owner Email column
        String ownerContact = (String) jTable1.getValueAt(row, 7); // Owner Contact column

        // Handle null or empty values
        if (status == null || status.trim().isEmpty()) {
            messageLabel.setText("<html>No status available.</html>");
            return;
        }
        if (ownerEmail == null) ownerEmail = "N/A";
        if (ownerContact == null) ownerContact = "N/A";

        // Update the message based on the status
        if ("approved".equalsIgnoreCase(status)) {
            messageLabel.setText("<html>Your request has been approved!<br>Owner Email: " + ownerEmail +
                                 "<br>Owner Contact: " + ownerContact + "</html>");
        } else if ("rejected".equalsIgnoreCase(status)) {
            messageLabel.setText("<html>Your request has been rejected.</html>");
        } else {
            messageLabel.setText("<html>The request is still pending.</html>");
        }
    }

    /**
     * Handles clicks on the "Status" column.
     * Updates the message label with detailed status and owner contact info.
     * @param row The row index of the clicked cell.
     */
    private void handleStatusClick(int row) {
        String status = (String) jTable1.getValueAt(row, 3);
        String ownerEmail = (String) jTable1.getValueAt(row, 6);
        String ownerContact = (String) jTable1.getValueAt(row, 7);

        if (status == null || status.trim().isEmpty()) {
            messageLabel.setText("<html>No status available.</html>");
            return;
        }

        if (ownerEmail == null) ownerEmail = "N/A";
        if (ownerContact == null) ownerContact = "N/A";

        if ("approved".equalsIgnoreCase(status)) {
            messageLabel.setText("<html>Your request has been approved!<br>Owner Email: " + ownerEmail +
                                 "<br>Owner Contact: " + ownerContact + "</html>");
        } else if ("rejected".equalsIgnoreCase(status)) {
            messageLabel.setText("<html>Your request has been rejected.</html>");
        } else {
            messageLabel.setText("<html>The request is still pending.</html>");
        }
    }

    /**
     * Handles clicks on the "Invoice" column.
     * Displays an invoice popup for the selected rental item.
     * @param row The row index of the clicked cell.
     */
    private void handleInvoiceClick(int row) {
        // Retrieve item details from the table
        String status = (String) jTable1.getValueAt(row, 3); // Status column
        String itemName = (String) jTable1.getValueAt(row, 1);
        String renter = (String) jTable1.getValueAt(row, 2);
        int daysRequested = (int) jTable1.getValueAt(row, 5);

        if (!"approved".equalsIgnoreCase(status)) {
            // Show message for non-approved requests
            String message = "Request rejected or waiting for approval.";
            messageLabel.setText("<html><body><h3>Invoice</h3><p>" + message + "</p></body></html>");
            return;
        }

        // For approved requests, generate the invoice
        double pricePerDay = 20.00; // Assume PHP 20 per day for this example
        double vatRate = 0.12; // Philippine VAT rate: 12%

        // Compute total cost and VAT
        double totalCostBeforeVAT = pricePerDay * daysRequested;
        double vatAmount = totalCostBeforeVAT * vatRate;
        double totalCostWithVAT = totalCostBeforeVAT + vatAmount;

        // Format the invoice details
        String invoice = String.format(
            "<html><body>" +
            "<h3>Invoice</h3>" +
            "<p><b>Item Name:</b> %s</p>" +
            "<p><b>Renter:</b> %s</p>" +
            "<p><b>Days Rented:</b> %d</p>" +
            "<p><b>Price per Day:</b> PHP %.2f</p>" +
            "<p><b>Total Cost (Before VAT):</b> PHP %.2f</p>" +
            "<p><b>VAT (12%%):</b> PHP %.2f</p>" +
            "<p><b>Total Cost (With VAT):</b> PHP %.2f</p>" +
            "</body></html>",
            itemName, renter, daysRequested, pricePerDay, totalCostBeforeVAT, vatAmount, totalCostWithVAT
        );

        // Display the invoice in the messageLabel
        messageLabel.setText(invoice);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        logoutButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        tablePanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        messagePanel = new javax.swing.JPanel();
        messageLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 600));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 51, 102));
        jPanel1.setPreferredSize(new java.awt.Dimension(100, 520));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 530, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, -1, 530));

        jPanel2.setBackground(new java.awt.Color(0, 51, 102));
        jPanel2.setPreferredSize(new java.awt.Dimension(1000, 75));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gearshare/GearShareLogo.png"))); // NOI18N

        logoutButton.setBackground(new java.awt.Color(255, 255, 255));
        logoutButton.setForeground(new java.awt.Color(0, 51, 102));
        logoutButton.setText("↪");
        logoutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutButtonActionPerformed(evt);
            }
        });

        backButton.setBackground(new java.awt.Color(255, 255, 255));
        backButton.setForeground(new java.awt.Color(0, 51, 102));
        backButton.setText("🔙");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(backButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 318, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(382, 382, 382)
                .addComponent(logoutButton)
                .addGap(27, 27, 27))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(logoutButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(backButton)
                .addGap(24, 24, 24))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        tablePanel.setBackground(new java.awt.Color(255, 255, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Request ID", "Item Name", "Renter", "Status", "Request Date", "Days Requested", "Owner Email", "Owner Contact", "Invoice"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setResizable(false);
            jTable1.getColumnModel().getColumn(5).setResizable(false);
            jTable1.getColumnModel().getColumn(6).setResizable(false);
            jTable1.getColumnModel().getColumn(7).setResizable(false);
            jTable1.getColumnModel().getColumn(8).setResizable(false);
        }

        messagePanel.setBackground(new java.awt.Color(240, 240, 240));
        messagePanel.setBorder(BorderFactory.createLineBorder(Color.GRAY)); // Optional: Add a border
        messagePanel.setForeground(new java.awt.Color(0, 51, 102));

        messageLabel.setOpaque(true); // Allow background color to be visible
        messageLabel.setBackground(Color.WHITE); // Set a white background
        messageLabel.setForeground(new Color(0, 51, 102)); // Set the text color
        messageLabel.setHorizontalAlignment(SwingConstants.CENTER); // Center the text horizontally
        messageLabel.setVerticalAlignment(SwingConstants.CENTER); // Center the text vertically
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 14));

        javax.swing.GroupLayout messagePanelLayout = new javax.swing.GroupLayout(messagePanel);
        messagePanel.setLayout(messagePanelLayout);
        messagePanelLayout.setHorizontalGroup(
            messagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(messagePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(messageLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE)
                .addContainerGap())
        );
        messagePanelLayout.setVerticalGroup(
            messagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(messagePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(messageLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 289, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout tablePanelLayout = new javax.swing.GroupLayout(tablePanel);
        tablePanel.setLayout(tablePanelLayout);
        tablePanelLayout.setHorizontalGroup(
            tablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tablePanelLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 688, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(messagePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 13, Short.MAX_VALUE))
        );
        tablePanelLayout.setVerticalGroup(
            tablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 480, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tablePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(messagePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(76, 76, 76))
        );

        getContentPane().add(tablePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, 890, 480));

        setSize(new java.awt.Dimension(1000, 600));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        new Dashboard(username, "user").setVisible(true); // Replace "user" with the correct role if needed
        this.dispose();
    }//GEN-LAST:event_backButtonActionPerformed

    private void logoutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutButtonActionPerformed
        // TODO add your handling code here:
        new Login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logoutButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RentedItemsFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RentedItemsFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RentedItemsFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RentedItemsFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new RentedItemsFrame("owner_username").setVisible(true); // Replace with actual username
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton logoutButton;
    private javax.swing.JLabel messageLabel;
    private javax.swing.JPanel messagePanel;
    private javax.swing.JPanel tablePanel;
    // End of variables declaration//GEN-END:variables
}
